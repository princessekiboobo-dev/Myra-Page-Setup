# Myra — current product facts

Prepared from the current codebase, 12 October 2026. These describe implemented functionality; they are not a claim that every workflow has passed live acceptance testing.

## Identity

- Product: Myra, a Windows desktop work companion.
- Creator: the team at Utterance. Founder and CEO: Prince Ssekiboobo.
- Tagline: A little less work.
- Current application version: 0.1.0, beta.

## Implemented features

- Chat by text and intentional hold-to-talk voice input, with streamed spoken replies when speech services and microphone permission are configured.
- An animated character, a fixed-size main window and a compact floating peeker. The peeker expands on hover and includes voice, short text entry, screen-region sharing and task status.
- Share a selected screen region through “Look at this” and ask questions about it when image understanding is configured. Images are attached once and remain as conversation thumbnails.
- File and folder search, text reading/writing, copying, moving, renaming, organization, duplicate inspection, ZIP creation/extraction and recoverable deletion. Eligible journaled file operations support recovery and undo/redo.
- Browser tasks through Myra's managed Chromium browser, or a paired Chrome/Edge extension: navigation, reading, extraction, forms and supported uploads/downloads. Personal browser access requires extension setup and site permissions.
- Local memory and recent task context, with memory management in settings. Saved routines provide reusable workflow instructions that are replanned with current inputs.
- Task progress, cancellation, clarification and approval prompts, and opening/revealing verified output files.
- Microsoft Office integration for supported Excel, Word and basic PowerPoint operations when Office is installed on Windows.

## Partially validated features — do not advertise as universally working

- Windows computer use is implemented through app discovery, launching, window control, UI Automation, editable controls, menus, dialogs and supported shortcuts. Broad end-to-end acceptance testing remains incomplete. The full Notepad edit/save/readback scenario has not been verified.
- Visual computer-control fallback is implemented for an explicitly approved, verified application window. Configuration and image-capable model requests have been checked, but real desktop visual interaction has not been verified end to end. Do not present this as a finished, reliable visual-control feature.
- Office and browser operations are bounded to supported actions; compatibility and success depend on the particular application, page, permissions and environment.

## Requirements and limits

- Windows desktop application. Windows 10 is the current development/test environment; this asset pack does not certify every Windows version or hardware configuration.
- Conversational AI and speech require configured services and internet access. Latency varies; sub-second responses are not guaranteed.
- No always-on ambient listening, continuous screen monitoring, webcam viewing or live video understanding.
- Old image thumbnails do not resend their pixels. Direct local-image loading into the conversation is not connected.
- Login credentials, MFA and CAPTCHA require human involvement. Arbitrary command execution, software installation and universal application control are not supported promises.
- Memory is bounded and can be incomplete. Undo does not cover arbitrary browser/cloud actions or desktop clicks.
- Filesystem approvals and protected-folder rules apply. The app does not guarantee zero errors or immunity to service outages.

## Code sources

`package.json`; `packages/companion/capabilities.ts`; `packages/companion/provider.ts`; `packages/companion/service.ts`; `packages/task/compiler.ts`; `packages/task/engine.ts`; `packages/actions/cua.ts`; `packages/actions/filesystem.ts`; `apps/desktop/renderer/App.tsx`; `apps/desktop/renderer/polish.css`.
